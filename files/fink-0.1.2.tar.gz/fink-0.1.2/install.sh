#!/bin/sh -e
#
# install.sh - the Fink installation shells cript
#
# Fink - a package manager that downloads source and installs it
# Copyright (c) 2001 Christoph Pfisterer
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#

if [ $# -lt 1 ]; then
  echo "Usage: ./install.sh <directory>"
  echo "  Example: ./install.sh /sw"
  exit 1
fi

basepath=$1

echo "Creating directories..."
mkdir -p $basepath/fink
mkdir -p $basepath/stow/system/bin
mkdir -p $basepath/stow/local
mkdir -p $basepath/var
mkdir -p $basepath/src

echo "Copying files..."
cp -r fink info patch perlmod update $basepath/fink
( cd $basepath/stow/system/bin; ln -s ../../../fink/fink fink )

echo "Creating init scripts..."
sed "s|BASEPATH|$basepath|g" <init.sh.in >$basepath/stow/system/bin/init.sh
sed "s|BASEPATH|$basepath|g" <init.csh.in >$basepath/stow/system/bin/init.csh

echo "Setting up stow hierarchy..."
( cd $basepath; ln -s stow/system/bin bin )
touch $basepath/var/.placeholder

echo "To complete Fink setup, run:"
echo " $basepath/bin/fink install stow"
echo "This will interactively create a configuration and then download and install"
echo "GNU stow, which is used to manage the hierarchy."
echo "Have fun, and remember: this is a very early release. You're walking on thin"
echo "ground. You have been warned. Send feedback to <fink@chrisp.de>"

exit 0
