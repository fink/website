#
# Fink::Bootstrap module
#
# Fink - a package manager that downloads source and installs it
# Copyright (c) 2001 Christoph Pfisterer
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#

package Fink::Bootstrap;

use Fink::Services qw(prompt prompt_boolean print_breaking);

use strict;
use warnings;

BEGIN {
  use Exporter ();
  our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  $VERSION = 1.00;
  @ISA         = qw(Exporter);
  @EXPORT      = qw();
  @EXPORT_OK   = qw(&bootstrap);
  %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],
}
our @EXPORT_OK;

# non-exported package globals go here
#our $linelength;

# initialize package globals, first exported ones
#$Var1   = '';
#%Hashit = ();

# then the others (which are still accessible as $Some::Module::stuff)
#$linelength = 77;

# all file-scoped lexicals must be created before
# the functions below that use them.

# file-private lexicals go here
#my $priv_var    = '';
#my %secret_hash = ();

# here's a file-private function as a closure,
# callable as &$priv_func;  it cannot be prototyped.
#my $priv_func = sub {
#  # stuff goes here.
#};

END { }       # module clean-up code here (global destructor)


### create configuration interactively

sub bootstrap {
  my $configpath = shift;
  my ($basepath, $umask, $otherdir);

  print "\n";
  &print_breaking("OK, I'll ask you some questions and afterwards put a ".
		  "configuration file in '$configpath'.");
  $basepath =
    &prompt("Where will the hierarchy reside? /sw is ".
	    "strongly recommended, other paths may not ".
	    "work right now.", "/sw");
  $umask =
    &prompt("What umask should be used by Fink? If you don't want ".
	    "Fink to set a umask, type 'none'.", "022");
  $otherdir =
    &prompt("In what additional directory should Fink look for downloaded ".
	    "tarballs?", "");

  &print_breaking("I'll now write the configuration to '$configpath' ".
		  "and continue normal operation.");
  open(OUT,">$configpath") or die "can't write $configpath: $!";
  print OUT "Basepath: $basepath\n";
  print OUT "UMask: $umask\n"
    unless $umask =~ /none/i;
  print OUT "FetchAltDir: $otherdir\n"
    if $otherdir;
  close(OUT) or die "can't write $configpath: $!";
}


### EOF
1;
