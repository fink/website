#
# Fink::PkgVersion class
#
# Fink - a package manager that downloads source and installs it
# Copyright (c) 2001 Christoph Pfisterer
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#

package Fink::PkgVersion;
use Fink::Base;

use Fink::Services qw(filename expand_percent expand_url execute find_stow);
use Fink::Package;
use Fink::Config qw($config $basepath);

use strict;
use warnings;

BEGIN {
  use Exporter ();
  our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  $VERSION = 1.00;
  @ISA         = qw(Exporter Fink::Base);
  @EXPORT      = qw();
  @EXPORT_OK   = qw();  # eg: qw($Var1 %Hashit &func3);
  %EXPORT_TAGS = ( );   # eg: TAG => [ qw!name1 name2! ],
}
our @EXPORT_OK;

END { }       # module clean-up code here (global destructor)


### self-initialization

sub initialize {
  my $self = shift;
  my ($pkgname, $version, $revision, $source);
  my ($depspec, $deplist, $dep);

  $self->SUPER::initialize();

  $self->{_name} = $pkgname = $self->param_default("Package", "");
  $self->{_version} = $version = $self->param_default("Version", "0");
  $self->{_revision} = $revision = $self->param_default("Revision", "0");

  # parse dependencies
  $depspec = $self->param_default("Depends", "");
  $deplist = [];
  foreach $dep (split(/\,\s*|\s+/, $depspec)) {
    next if $dep eq "x11";
    push @$deplist, $dep;
  }
  $self->{_depends} = $deplist;

  $source = $self->param_default("Source", "\%n-\%v.tar.gz");
  if ($source eq "gnu") {
    $source = "mirror:gnu:\%n/\%n-\%v.tar.gz";
  }

  $source = &expand_percent($source, { 'n' => $pkgname,
				       'v' => $version });
  $self->{source} = $source;
}

### get package name

sub get_name {
  my $self = shift;
  return $self->{_name};
}

### get version string

sub get_version {
  # return version or version-revision here ?

  my $self = shift;
  return $self->{_version};
}

sub get_onlyversion {
  my $self = shift;
  return $self->{_version};
}

### get revision string

sub get_revision {
  my $self = shift;
  return $self->{_revision};
}

### get complete version specification (version plus revision)

sub get_fullversion {
  my $self = shift;
  return $self->{_version}."-".$self->{_revision};
}

### other accessors

sub get_source {
  my $self = shift;
  return $self->param("Source");
}

sub get_tarball {
  my $self = shift;
  return &filename($self->param("Source"));
}

sub get_build_directory {
  my $self = shift;
  my ($dir);

  if ($self->has_param("SourceDirectory")) {
    return $self->param("SourceDirectory");
  }

  $dir = $self->get_tarball();
  if ($dir =~ /^(.*)\.tar\.(gz|Z|bz2)$/) {
    $dir = $1;
  }
  if ($dir =~ /^(.*)\.tgz$/) {
    $dir = $1;
  }

  return $dir;
}

sub get_stow_directory {
  my $self = shift;
  return $self->get_name()."-".$self->get_fullversion();
}

### get installation state

sub is_present {
  my $self = shift;
  my ($idir);

  $idir = "$basepath/stow/".$self->get_stow_directory();

  if (-e "$idir/var/fink-stamp/".$self->get_stow_directory()) {
    return 1;
  }
  return 0;
}

sub is_installed {
  my $self = shift;

  if (-e "$basepath/var/fink-stamp/".$self->get_stow_directory()) {
    return 1;
  }
  return 0;
}

### check dependencies

sub get_missing_depends_rec {
  my $self = shift;
  my ($dep, $dep_package, @deplist);

  @deplist = ();
  foreach $dep (@{$self->{_depends}}) {
    $dep_package = Fink::PkgVersion->match_package($dep, 1);
    unless (defined $dep_package) {
      die "no package found for specification '$dep'!";
    }
    next if $dep_package->is_installed();
    push @deplist, $dep;
    push @deplist, $dep_package->get_missing_depends_rec();
  }
  return @deplist;
}

sub get_missing_depends_onelevel {
  my $self = shift;
  my ($dep, $dep_package, @deplist);

  @deplist = ();
  foreach $dep (@{$self->{_depends}}) {
    $dep_package = Fink::PkgVersion->match_package($dep, 1);
    unless (defined $dep_package) {
      die "no package found for specification '$dep'!";
    }
    next if $dep_package->is_installed();
    push @deplist, $dep;
  }
  return @deplist;
}

sub get_missing_depends {
  my $self = shift;
  my (@deplist, %dephash, $dep);

  @deplist = $self->get_missing_depends_rec();
  %dephash = ();
  foreach $dep (@deplist) {
    $dephash{$dep} = 1;
  }
  return sort keys %dephash;
}


### find package and version by matching a specification

sub match_package {
  shift;  # class method - ignore first parameter
  my $s = shift;
  my $quiet = shift || 0;

  my ($pkgname, $package, $version, $pkgversion);
  my ($found, @parts, $i, @vlist, $v, @rlist);


  # first, search for package
  $found = 0;
  $package = Fink::Package->package_by_name($s);
  if (defined $package) {
    $found = 1;
    $pkgname = $package->get_name();
    $version = "###";
  } else {
    # try to separate version from name (longest match)
    @parts = split(/-/, $s);
    for ($i = $#parts - 1; $i >= 0; $i--) {
      $pkgname = join("-", @parts[0..$i]);
      $version = join("-", @parts[$i+1..$#parts]);
      $package = Fink::Package->package_by_name($pkgname);
      if (defined $package) {
	$found = 1;
	last;
      }
    }
  }
  if (not $found) {
    print "no package found for \"$s\"\n"
      unless $quiet;
    return undef;
  }

  # DEBUG
  print "pkg $pkgname  version $version\n"
    unless $quiet;

  # we now have the package name in $pkgname, the package
  # object in $package, and the
  # still to be matched version (or "###") in $version.
  if ($version eq "###") {
    # find the newest version

    @vlist = sort $package->list_versions();
    if ($#vlist >= 0) {
      $version = $vlist[$#vlist];
      print "pkg $pkgname  version $version\n"
	unless $quiet;
    } else {
      # there's nothing we can do here...
      die "no version info available for $pkgname";
    }
  } elsif (not defined $package->get_version($version)) {
    # try to match the version

    @vlist = $package->list_versions();
    @rlist = ();
    foreach $v (@vlist)  {
      if ($package->get_version($v)->get_onlyversion() eq $version) {
	push @rlist, $v;
      }
    }
    @rlist = sort @rlist;
    if ($#rlist >= 0) {
      $version = $rlist[$#rlist];
      print "pkg $pkgname  version $version\n"
	unless $quiet;
    } else {
      # there's nothing we can do here...
      die "no matching version found for $pkgname";
    }
  }

  return $package->get_version($version);
}

###
### PHASES
###

### fetch

sub phase_fetch {
  my $self = shift;
  my ($url, $file);

  $url = &expand_url($self->get_source());
  print "$url\n";

  chdir "$basepath/src";
  $file = $self->get_tarball();
  if (-f $file) {
    &execute("rm -f $file");
  }
  &execute("wget $url");
  # TODO: check file exists
}

### unpack

sub phase_unpack {
  my $self = shift;
  my ($archive, $found_archive, $dir, $tar_cmd);
  my (@search_dirs, $search_dir, $iter);

  $archive = $self->get_tarball();
  $dir = $self->get_build_directory();

  # compile list of dirs to search
  @search_dirs = ( "$basepath/src" );
  if ($config->has_param("FetchAltDir")) {
    push @search_dirs, $config->param("FetchAltDir");
  }

  # search for archive, try fetching once if not found
  $iter = 0;
 FINDTARBALL: while (1) {
    foreach $search_dir (@search_dirs) {
      $found_archive = "$search_dir/$archive";
      if (-f $found_archive) {
	last FINDTARBALL;
      }
    }
    if ($iter) {
      die "can't find source tarball $archive!";
    }
    $iter = 1;
    $self->phase_fetch();
  }

  # determine unpacking command
  $tar_cmd = "tar -xvf $found_archive";
  if ($archive =~ /[\.\-]tar\.(gz|Z)$/ or $archive =~ /\.tgz$/) {
    $tar_cmd = "gzip -dc $found_archive | tar -xvf -";
  } elsif ($archive =~ /[\.\-]tar\.bz2$/) {
    $tar_cmd = "bzip2 -dc $found_archive | tar -xvf -";
  }

  # remove dir if it exists
  chdir "$basepath/src";
  if (-e $dir) {
    if (&execute("rm -rf $dir")) {
      die "can't remove existing directory $dir";
    }
  }
  if (&execute($tar_cmd)) {
    die "unpacking failed";
  }
}

### patch

sub phase_patch {
  # nop right now
}

### compile

sub phase_compile {
  my $self = shift;
  my ($dir, $idir, $expand);
  my ($configure_params, $compile_script, $cmd);

  $dir = $self->get_build_directory();
  $idir = "$basepath/stow/".$self->get_stow_directory();

  chdir "$basepath/src/$dir";

  # collect parameters for configure
  $configure_params = $self->param_default("ConfigureParams", "");
  if ($self->param_boolean("UsesGettext")) {
    $configure_params .= " --with-included-gettext";
  }
  $configure_params = "--prefix=$basepath ".$configure_params;

  # generate compilation script
  $compile_script = "./configure \%c\n".
    "make";
  if ($self->has_param("CompileScript")) {
    $compile_script = $self->param("CompileScript");
  }

  $expand = { 'n' => $self->get_name(),
	      'v' => $self->get_onlyversion(),
	      'r' => $self->get_revision(),
	      'p' => $basepath,
	      'i' => $idir,
	      'c' => $configure_params };
  $compile_script = &expand_percent($compile_script, $expand);


  ### copy host type scripts (config.guess and config.sub) if required

  if ($self->param_boolean("UpdateConfigGuess")) {
    &execute("cp -f $basepath/fink/update/config.guess .");
    &execute("cp -f $basepath/fink/update/config.sub .");
  }

  ### copy libtool scripts (ltconfig and ltmain.sh) if required

  if ($self->param_boolean("UpdateLibtool")) {
    &execute("cp -f $basepath/fink/update/ltconfig .");
    &execute("cp -f $basepath/fink/update/ltmain.sh .");
  }

  ### set environment

  $self->set_env($expand);

  ### compile

  foreach $cmd (split(/\n/,$compile_script)) {
    next unless $cmd;   # skip empty lines

    if (&execute($cmd)) {
      die "compiling failed";
    }
  }
}

### install

sub phase_install {
  my $self = shift;
  my ($dir, $idir, $expand);
  my ($install_script, $cmd);

  $dir = $self->get_build_directory();
  $idir = "$basepath/stow/".$self->get_stow_directory();

  chdir "$basepath/src/$dir";

  # generate installation script
  $install_script = "rm -rf \%i\n".
    "mkdir -p \%i\n";
  if ($self->has_param("InstallScript")) {
    $install_script .= $self->param("InstallScript");
  } else {
    $install_script .= "make install prefix=\%i";
  }
  $install_script .= "\nmkdir -p \%i/var/fink-stamp".
    "\ntouch \%i/var/fink-stamp/".$self->get_stow_directory();

  $expand = { 'n' => $self->get_name(),
	      'v' => $self->get_onlyversion(),
	      'r' => $self->get_revision(),
	      'p' => $basepath,
	      'i' => $idir };
  $install_script = &expand_percent($install_script, $expand);

  ### set environment

  $self->set_env($expand);

  ### install

  foreach $cmd (split(/\n/,$install_script)) {
    next unless $cmd;   # skip empty lines

    if (&execute($cmd)) {
      die "installing failed";
    }
  }
}

### activate

sub phase_activate {
  my $self = shift;
  my ($dir, $stow);

  $dir = $self->get_stow_directory();

  chdir "$basepath/stow";
  if (-d $dir) {
    # avoid conflicts for info documentation
    if (-f "$dir/info/dir") {
      &execute("rm -f $dir/info/dir");
    }

    $stow = &find_stow;

    if (&execute("$stow $dir")) {
      die "stow failed";
    }
  } else {
    die "Package directory $dir not found unter $basepath/stow!";
  }
}

### deactivate

sub phase_deactivate {
  my $self = shift;
  my ($dir, $stow);

  $dir = $self->get_stow_directory();

  chdir "$basepath/stow";
  if (-d $dir) {
    $stow = &find_stow;

    if (&execute("$stow -D $dir")) {
      die "stow failed";
    }
  } else {
    die "Package directory $dir not found unter $basepath/stow!";
  }
}

### set environment variables according to spec

sub set_env {
  my $self = shift;
  my $expand = shift;
  my ($varname, $s);

  foreach $varname ("CC", "CFLAGS",
		    "CPP", "CPPFLAGS",
		    "LD", "LDFLAGS", "LIBS",
		    "MAKE", "MFLAGS") {
    if ($self->has_param("Set$varname")) {
      $s = $self->param("Set$varname");
      $ENV{$varname} = &expand_percent($s, $expand);
    } else {
      delete $ENV{$varname};
    }
  }
}


### EOF
1;
