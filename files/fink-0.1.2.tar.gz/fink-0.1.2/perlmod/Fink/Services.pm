#
# Fink::Services module
#
# Fink - a package manager that downloads source and installs it
# Copyright (c) 2001 Christoph Pfisterer
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#

package Fink::Services;

use Fink::Config qw($config $basepath);
use FindBin;

use strict;
use warnings;

BEGIN {
  use Exporter ();
  our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  $VERSION = 1.00;
  @ISA         = qw(Exporter);
  @EXPORT      = qw();
  %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

  # your exported package globals go here,
  # as well as any optionally exported functions
  @EXPORT_OK   = qw(&read_config &read_properties &read_properties_multival &filename &execute &expand_percent &print_breaking &prompt &prompt_boolean &find_stow &expand_url);
}
our @EXPORT_OK;

# non-exported package globals go here
our $linelength;

# initialize package globals, first exported ones
#$Var1   = '';
#%Hashit = ();

# then the others (which are still accessible as $Some::Module::stuff)
$linelength = 77;

# all file-scoped lexicals must be created before
# the functions below that use them.

# file-private lexicals go here
#my $priv_var    = '';
#my %secret_hash = ();

# here's a file-private function as a closure,
# callable as &$priv_func;  it cannot be prototyped.
#my $priv_func = sub {
#  # stuff goes here.
#};

# make all your functions, whether exported or not;
# remember to put something interesting in the {} stubs
#sub func1      {}    # no prototype
#sub func2()    {}    # proto'd void
#sub func3($$)  {}    # proto'd to 2 scalars

# this one isn't exported, but could be called!
#sub func4(\%)  {}    # proto'd to 1 hash ref

END { }       # module clean-up code here (global destructor)


### create configuration

sub read_config {
  my $filename = shift;
  my ($config_properties, $config_object);

  $config_properties = read_properties($filename);
  $config_object = Fink::Config->new_from_properties($config_properties);
  return $config_object;
}

### read properties file

sub read_properties {
  my ($file) = @_;
  my ($hash, $lastkey);

  $hash = {};
  $lastkey = "";

  open(IN,$file) or die "can't open $file: $!";
  while (<IN>) {
    next if /^\s*\#/;   # skip comments
    if (/^([0-9A-Za-z_.\-]+)\:\s*(\S.*)$/) {
      $lastkey = lc $1;
      $hash->{$lastkey} = $2;
    } elsif (/^\s+(\S.*)$/) {
      $hash->{$lastkey} .= "\n".$1;
    }
  }
  close(IN);

  return $hash;
}

### read properties file with multiple values per key

sub read_properties_multival {
  my ($file) = @_;
  my ($hash, $lastkey, $lastindex);

  $hash = {};
  $lastkey = "";
  $lastindex = 0;

  open(IN,$file) or die "can't open $file: $!";
  while (<IN>) {
    next if /^\s*\#/;   # skip comments
    if (/^([0-9A-Za-z_.\-]+)\:\s*(\S.*)$/) {
      $lastkey = lc $1;
      if (exists $hash->{$lastkey}) {
	$lastindex = @{$hash->{$lastkey}};
	$hash->{$lastkey}->[$lastindex] = $2;
      } else {
	$lastindex = 0;
	$hash->{$lastkey} = [ $2 ];
      }
    } elsif (/^\s+(\S.*)$/) {
      $hash->{$lastkey}->[$lastindex] .= "\n".$1;
    }
  }
  close(IN);

  return $hash;
}

### execute command

sub execute {
  my $cmd = shift;
  my ($retval, $prog);

  print "$cmd\n";
  $retval = system($cmd);
  $retval >>= 8 if defined $retval;
  if ($retval) {
    ($prog) = split(/\s+/, $cmd);
    print "### $prog failed, exit code $retval\n";
  }
  return $retval;
}

### do % substitutions on a string

sub expand_percent {
  my $s = shift;
  my $map = shift;
  my ($key, $value);

  while (($key, $value) = each %$map) {
    $s =~ s/\%$key/$value/g;
  }

  return $s;
}

### expand mirror urls

sub expand_url {
  my $s = shift;
  my ($mirror, $path);

  if ($s =~ /^mirror\:(\w+)\:(.*)$/) {
    $mirror = $1;
    $path = $2;

    if ($config->has_param("mirror-$mirror")) {
      $s = $config->param("mirror-$mirror");
      $s .= "/" unless $s =~ /\/$/;
      $s .= $path;
    } else {
      die "can't find url for mirror $mirror in configuration";
    }
  }

  return $s;
}

### isolate filename from path

sub filename {
  my ($s) = @_;

  if ($s =~ /\/([^\/]+)$/) {
    $s = $1;
  }
  return $s;
}

### user interaction

sub print_breaking {
  my $s = shift;
  my $linebreak = shift;
  $linebreak = 1 unless defined $linebreak;
  my ($pos, $t);

  chomp($s);
  while (length($s) > $linelength) {
    $pos = rindex($s," ",$linelength);
    if ($pos < 0) {
      $t = substr($s,0,$linelength);
      $s = substr($s,$linelength);
    } else {
      $t = substr($s,0,$pos);
      $s = substr($s,$pos+1);
    }
    print "$t\n";
  }
  print $s;
  print "\n" if $linebreak;
}

sub prompt {
  my $prompt = shift;
  my $default_value = shift;
  $default_value = "" unless defined $default_value;
  my ($answer);

  &print_breaking("$prompt [$default_value] ", 0);
  $answer = <STDIN>;
  chomp($answer);
  $answer = $default_value if $answer eq "";
  return $answer;
}

sub prompt_boolean {
  my $prompt = shift;
  my $default_value = shift;
  $default_value = 1 unless defined $default_value;
  my ($answer, $meaning);

  while (1) {
    &print_breaking("$prompt [".($default_value ? "Y/n" : "y/N")."] ", 0);
    $answer = <STDIN>;
    chomp($answer);
    if ($answer eq "") {
      $meaning = $default_value;
      last;
    } elsif ($answer =~ /^y(e?s)?/i) {
      $meaning = 1;
      last;
    } elsif ($answer =~ /^no?/i) {
      $meaning = 0;
      last;
    }
  }

  return $meaning;
}

### find stow binary

sub find_stow {
  my $fn;

  foreach $fn ("$basepath/bin/stow", "$FindBin::Bin/stow",
               glob("$basepath/stow/stow*/bin/stow")) {
    if (-x $fn) {
      return $fn;
    }
  }
  print "Warning: stow not found, I hope it's in the PATH somewhere...\n";
  return "stow";
}


### EOF
1;
