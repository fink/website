#
# Fink::Engine class
#
# Fink - a package manager that downloads source and installs it
# Copyright (c) 2001 Christoph Pfisterer
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#

package Fink::Engine;

use Fink::Services qw(&prompt_boolean);
use Fink::Package;
use Fink::PkgVersion;
use Fink::Config qw($basepath);

use strict;
use warnings;

BEGIN {
  use Exporter ();
  our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  $VERSION = 1.00;
  @ISA         = qw(Exporter);
  @EXPORT      = qw();
  @EXPORT_OK   = qw();  # eg: qw($Var1 %Hashit &func3);
  %EXPORT_TAGS = ( );   # eg: TAG => [ qw!name1 name2! ],
}
our @EXPORT_OK;

our %simple_commands =
  ( 'rescan' => \&cmd_rescan );
our %package_commands =
  ( 'fetch' => \&cmd_fetch,
    'build' => \&cmd_build,
    'enable' => \&cmd_activate,
    'activate' => \&cmd_activate,
    'use' => \&cmd_activate,
    'disable' => \&cmd_deactivate,
    'deactivate' => \&cmd_deactivate,
    'unuse' => \&cmd_deactivate,
    'install' => \&cmd_install,
  );

END { }       # module clean-up code here (global destructor)

### constructor using configuration

sub new_with_config {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $config_object = shift;

  my $self = {};
  bless($self, $class);

  $self->{config} = $config_object;

  $self->initialize();

  return $self;
}

### self-initialization

sub initialize {
  my $self = shift;
  my $config = $self->{config};
  my ($basepath);

  $self->{basepath} = $basepath = $config->param("basepath");
  if (!$basepath) {
    die "Basepath not set in config file!";
  }

  print "Reading package info...\n";
  Fink::Package->scan($basepath."/fink/info");

  if ($config->has_param("umask")) {
    umask oct($config->param("umask"));
  }
}

### process command

sub process {
  my $self = shift;
  my $cmd = shift;
  my ($pkgspec, $package);

  unless (defined $cmd) {
    print "NOP\n";
    return;
  }

  my ($cmdname, $proc);
  while (($cmdname, $proc) = each %simple_commands) {
    if ($cmd eq $cmdname) {
      &$proc();
      print "Done.\n";
      return;
    }
  }
  while (($cmdname, $proc) = each %package_commands) {
    if ($cmd eq $cmdname) {
      $pkgspec = shift;
      unless (defined $pkgspec) {
	die "no package specified for command '$cmd'!";
      }
      $package = Fink::PkgVersion->match_package($pkgspec);
      unless (defined $package) {
	die "no package found for specification '$pkgspec'!";
      }
      &$proc($package);
      print "Done.\n";
      return;
    }
  }

  die "unknown command: $cmd";
}

### dependency stuff

sub phase_depcheck {
  my $package = shift;
  my (@deplist, $answer);

  @deplist = $package->get_missing_depends();
  if ($#deplist >= 0) {
    $answer =
      &prompt_boolean("The package ".$package->get_name()." depends on the ".
		      "following missing packages: ".
		      join(" ",@deplist).
		      ". They must be installed before ".
		      $package->get_name().
		      " can be installed. Do you want to install all ".
		      "required packages?", 1);
    if (! $answer) {
      die "Dependencies not satisfied";
    }

    &helper_install_depends($package);
  }
}

### the commands

sub cmd_rescan {
  print "Re-reading package info...\n";
  Fink::Package->forget_packages();
  Fink::Package->scan($basepath."/fink/info");
}

sub cmd_fetch {
  my $package = shift;

  $package->phase_fetch();
}

sub cmd_build {
  my $package = shift;

  &phase_depcheck($package);

  $package->phase_unpack();
  $package->phase_patch();
  $package->phase_compile();
  $package->phase_install();
}

sub cmd_activate {
  my $package = shift;

  $package->phase_activate();
}

sub cmd_deactivate {
  my $package = shift;

  $package->phase_deactivate();
}

sub cmd_install {
  my $package = shift;

  &phase_depcheck($package);

  $package->phase_unpack();
  $package->phase_patch();
  $package->phase_compile();
  $package->phase_install();

  $package->phase_activate();
}

sub cmd_install_withdep {
  my $package = shift;

  &helper_install_depends($package);

  $package->phase_unpack();
  $package->phase_patch();
  $package->phase_compile();
  $package->phase_install();

  $package->phase_activate();
}

sub helper_install_depends {
  my $package = shift;
  my (@deplist, $dep, $dep_package);

  @deplist = $package->get_missing_depends_onelevel();
  foreach $dep (@deplist) {
    $dep_package = Fink::PkgVersion->match_package($dep, 1);
    unless (defined $dep_package) {
      die "no package found for specification '$dep'!";
    }
    &cmd_install_withdep($dep_package);
  }
}


### EOF
1;
